set define '^' verify off
prompt ...wwv_flow_rest_ws
create or replace PACKAGE wwv_flow_rest_ws AS
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 2017. All Rights Reserved.
--
--    NAME
--      wwv_flow_rest_ws.sql
--
--    DESCRIPTION
--     Manages Processing of the ORDS based REST Workshop
--
--    NOTES
--      This API is unsupported.
--
--    MODIFIED    (MM/DD/YYYY)
--     dgault     10/27/2017 - Created
--
--------------------------------------------------------------------------------\
--
-- Minimum ORDS version required to enable ORDS REST workshop
c_ords_major CONSTANT number := 17;
c_ords_minor CONSTANT number := 4;
c_ords_patch CONSTANT number := 1;
c_ords_day   CONSTANT number := 353;
-----------------------------------------------------------------------
--< PUBLIC METHODS >---------------------------------------------------
-----------------------------------------------------------------------

--< PROCESS_REST_WS >-------------------------------------------------

PROCEDURE PROCESS_REST_WS_REQUEST ( p_request in varchar2, p_parse_as in varchar2);

--< ENABLE_SCHEMA >-------------------------------------------------

PROCEDURE ENABLE_SCHEMA ( p_schema in varchar2, p_enable_access in varchar2, p_schema_alias in varchar2, p_auth_required in varchar2);

--< DROP_REST >-------------------------------------------------

PROCEDURE DROP_REST ( p_schema in varchar2);

--< ORDS_REPO_PRESENT >-------------------------------------------------

FUNCTION ORDS_REPO_PRESENT RETURN varchar2;

--< ORDS_MIN_VER_MET >--------------------------------------------------
FUNCTION ORDS_MIN_VER_MET (p_current_version in VARCHAR2) RETURN varchar2;

--< ORDS_IS_18_PLUS >--------------------------------------------------
FUNCTION ORDS_IS_18_PLUS (p_current_version in VARCHAR2) RETURN varchar2;

--< MODULE_IS_PROTECTED >-----------------------------------------------
FUNCTION MODULE_IS_PROTECTED(p_module_id in number) RETURN varchar2;

--< TEMPLATE_IS_PROTECTED >-----------------------------------------------
  FUNCTION template_IS_PROTECTED(p_template_id in number) RETURN varchar2;

END wwv_flow_rest_ws;
/
show errors
