set define '^'
set verify off
prompt ...development_service_home
prompt ...development_service_home, htmldb, apex
create or replace procedure apex wrapped 
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
7
5ee 2ea
maC/KlzUm6Kb9vxnsU6XZ7RRZkMwg9fDLiAGfC9Vgp0VnMU1g/C0VTPC5xSGWdMKJnkxyz5J
CsU+5ie9E6x3T53/HxQTCSbEkql+0MHX2TR45/q9zvQ20ktyGcja5p+9jGc+l4hRdC1dSPvT
Oi+PFDwzBMaG8ys9arQUl9SKo+ChZlaqvrG3+pF6eVFiWfB/pGLKGtgYs6ZjKSU2f66yvSYf
rN/3PBVa52ejR3UZ4cDiM8mQu2XHVkFkbsWz0Ufkmfp1Ly9F+lW8en7CGwyA3YP10unfsK6l
OPdGhxhsx/YlTYX5HAOxHSOXbaOcEPckyR4L92uwZqo18lLSbiCbhvtzZzEFM0tVeW7oHrtn
W1JRZoR89I/kYDuJH97uvbGhn2TGcyKWyzGrsr1w+/6cvfXZ8lD0kYGI2FohdUpgACKeWmYm
h0LwgnTu5Kesa1aPM4DWkVefrqkGXWQxNH8F/txLDeqUfsvtMFpzG0KFynp5LhZCZnSBxrJM
9v8DvybmX7G8uwVN9jjl48QUczCuiq+vyW2/9rgxB4E1288yW1n9cAzFrdX+aglz9PiC2mqu
ErujOEW/eTWu6XoyedV1JXXzdddyEJQutSGJO+zXkE+fJZAzRUW+vC14hiL1sbZcOlSvQ+Jx
G2bRtjpzLG36LtDp/taYPQfrm/d4l0qnknQHil5xJEijDJS52bUtCcZ3l19TlLrlA11PFHFR
p4R6czMo/2l5QQ==

/
grant execute on apex to public
/
create or replace procedure development_service_home wrapped 
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
7
96 ca
bhcCO+87LIvfxe0A9lZmGdqZJoQwgy5tNZ4VfI5ETMGOqjFBaxYa114d+q5agwbRmbLDSyvD
Iz/WCrxVpcnPuKR3L2fENIvGm+xOThMiOu0ZZK0u2W4m08OLXqJfg3/eGxx+bWeegK11vA5/
DcjMoFfe+R4lhgl5UXM4HTLv3eVd719Ob2ic1V9FhHvabcn+HS/OxXY=

/
grant execute on development_service_home to public
/
create or replace procedure htmldb wrapped 
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
7
6a 96
abZTYxi1fBuXZoNWv4nTZWnPzW4wg5nnm7+fMr2ywFyFFvrXoaEljwmmrKnOcLGPcK6qJESu
JESdaQ9JscpEH+p4xmlPL8qxxoC32X912fo9Veso2Gh/3SrmHaG3O6TTgOvs2T1ylez7poYN
/ag=

/
grant execute on htmldb to public
/
prompt ...login
create or replace procedure htmldb_login wrapped 
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
7
9d d6
qq4qtH10+wSTGZYp20+xKAT6mmYwgwBfr54VfC+iAMHVwAyZZp4zw6NaEzs5Bhv1tsd04w7m
PW210KgOxxKC0FIDpDUCiM5zTnHinKA0INAfZARyUvSpWrpdq61A66aC6nz6cM9gCycb9LK4
UFTSBHLeZd9IfRELQ/Fgm9OAfZK1s4OU7/cHNAriH9oIHp65E8nV/Kf75Z+BROPhxbg=

/
grant execute on htmldb_login to public
/
create or replace procedure development_service_home_login wrapped 
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
7
ce 103
LESaw0+JrC70nrXP6gs/LgYJ6a4wgwAuLpmsfAS5imS0LgLjrHr0rEWxdkd5fj92moTw0+Tj
nqqqhE3BM8/VYpkOOznAAwqknMGRwSi8zfak4m8s2ZFScblqWeHQVxYhcHS3rHw1orrBDr0C
ZfZChhbBa5yIlgeZtro0u9pWvooo6PEQDsi965FRqRRzKM09p2frqU7e8ZJJtbB50nbpgCRf
AC93TDLdY+U1IeJk2iumK8I5XSVM1JiWzv3a7w==

/
grant execute on development_service_home_login to public
/
create or replace procedure development_service_signup wrapped 
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
7
cb 10b
WDFtmmKK+MGFocjzZQW2duaHpJowg2JK2Z4VfI6iTMHVudFi43fG6G8CtBmDZ+xGGtABb6ui
pQI9P51jMiuCBzeIecMYk3kv/7z+xMEeuSwssTq/qgBCsUyW0LuZ4eHWoAMRYurTUzaTnFsh
yDj/J8yyzOPIfNqUazgbYnWTRB4WRs3LEVm2wN3vnAtref2cmT3RfmuDZ9AZCH7EsBNXGH3k
rn4CIxUMqxs2Ad+KKhaJ0cwrav3rpY6QQ4CTHpEzHU60eNw=

/
grant execute on development_service_signup to public
/
prompt ...done home
